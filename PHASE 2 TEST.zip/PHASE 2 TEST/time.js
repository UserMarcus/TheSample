


function updatePST() {
    const pstElement = document.getElementById('pstTime');
    const now = new Date();
    const options = { timeZone: 'Asia/Manila', hour12: true, hour: 'numeric', minute: 'numeric' };
    const pstTime = now.toLocaleString('en-US', options);
    pstElement.textContent = `Philippine Time: ${pstTime}`;
}


setInterval(updatePST, 1000);
